import "./style.css";
import { MODELS, cachedInfo, deleteCached, fmtBytes } from "./models.js";

const $ = (s) => document.querySelector(s);
const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
};

const state = {
  history: store.get("history", []),
  settings: {
    system: "You are a helpful assistant running privately on the user's phone. Be concise.",
    temperature: 0.7,
    maxTokens: 512,
    ...store.get("settings", {}),
  },
  customModels: store.get("customModels", []),
  lastModelId: store.get("modelId", null),
  loadedId: null,
  pending: null,
  loading: false,
  generating: false,
  device: null,
  reply: "",
  bubble: null,
};

const worker = new Worker(new URL("./worker.js", import.meta.url), { type: "module" });
const allModels = () => [...MODELS, ...state.customModels];
const modelName = (id) => (allModels().find((m) => m.id === id) || { name: id }).name;

/* ---------- small helpers ---------- */
function el(tag, props = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props)) {
    if (k === "class") n.className = v;
    else if (k.startsWith("on")) n.addEventListener(k.slice(2), v);
    else n[k] = v;
  }
  n.append(...kids);
  return n;
}
let toastTimer;
function toast(msg) {
  const t = $("#toast");
  t.textContent = msg; t.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => (t.hidden = true), 3200);
}

/* ---------- status line ---------- */
function setStatus() {
  const net = navigator.onLine ? "online" : "offline";
  let line;
  if (state.loading) line = "Loading model…";
  else if (state.loadedId) line = `${modelName(state.loadedId)} · ${state.device === "webgpu" ? "GPU" : "CPU (slower)"} · ${net}`;
  else line = `No model loaded · ${net}`;
  $("#status").textContent = line;
}
window.addEventListener("online", setStatus);
window.addEventListener("offline", setStatus);

/* ---------- chat rendering ---------- */
function addMsg(role, text) {
  $("#empty")?.remove();
  const b = el("div", { class: `msg ${role}` });
  b.textContent = text;
  $("#messages").append(b);
  scrollDown();
  return b;
}
function scrollDown() {
  const m = $("#messages");
  m.scrollTop = m.scrollHeight;
}
function updateComposer() {
  const ready = !!state.loadedId && !state.loading;
  $("#input").disabled = !ready;
  $("#sendBtn").disabled = !ready;
  $("#sendBtn").textContent = state.generating ? "Stop" : "Send";
  $("#input").placeholder = ready ? "Message" : "Load a model to start";
}

function send() {
  if (state.generating) { worker.postMessage({ type: "stop" }); return; }
  const input = $("#input");
  const text = input.value.trim();
  if (!text || !state.loadedId) return;
  input.value = ""; autosize();

  state.history.push({ role: "user", content: text });
  addMsg("user", text);
  state.bubble = addMsg("assistant", "");
  state.bubble.classList.add("streaming");
  state.reply = "";
  state.generating = true;
  updateComposer();

  worker.postMessage({
    type: "generate",
    messages: [{ role: "system", content: state.settings.system }, ...state.history.slice(-12)],
    params: { temperature: Number(state.settings.temperature), maxTokens: Number(state.settings.maxTokens) },
  });
}

function finishReply(extra) {
  state.generating = false;
  if (state.bubble) {
    state.bubble.classList.remove("streaming");
    if (state.reply.trim()) {
      state.history.push({ role: "assistant", content: state.reply });
      store.set("history", state.history.slice(-100));
      if (extra) state.bubble.append(el("span", { class: "meta" }, extra));
    } else {
      state.bubble.remove();
    }
  }
  state.bubble = null;
  updateComposer();
}

/* ---------- worker messages ---------- */
worker.onmessage = ({ data }) => {
  switch (data.type) {
    case "device":
      state.device = data.device;
      $("#loadLabel").textContent = data.device === "webgpu" ? "Preparing GPU model…" : "Preparing CPU (WASM) model…";
      break;
    case "progress": {
      const pct = data.total ? Math.min(100, (data.loaded / data.total) * 100) : 0;
      $("#loadProgress").value = pct;
      $("#loadPct").textContent = `${Math.round(pct)}% · ${fmtBytes(data.loaded)} / ${fmtBytes(data.total)}`;
      $("#loadLabel").textContent = "Downloading model…";
      break;
    }
    case "ready":
      state.loading = false;
      state.device = data.device;
      state.loadedId = state.pending.id;
      store.set("modelId", state.loadedId);
      $("#loadbar").hidden = true;
      if (navigator.storage?.persist) navigator.storage.persist();
      toast(`${modelName(state.loadedId)} ready`);
      setStatus(); updateComposer();
      if ($("#settings").open) renderModels();
      break;
    case "load-error":
      state.loading = false;
      $("#loadProgress").hidden = true;
      $("#loadLabel").textContent = "Could not load model";
      $("#loadPct").textContent = "";
      $("#loadError").hidden = false;
      $("#loadError").textContent =
        `${data.message}. Common causes: not enough memory (try a smaller model) or no connection during the first download.`;
      setStatus(); updateComposer();
      break;
    case "token":
      state.reply += data.text;
      if (state.bubble) {
        if (state.bubble.firstChild) state.bubble.firstChild.nodeValue = state.reply;
        else state.bubble.append(document.createTextNode(state.reply));
      }
      scrollDown();
      break;
    case "done":
      finishReply(data.tps ? `${data.tps.toFixed(1)} tokens/s` : "");
      break;
    case "gen-error":
      toast("Reply failed: " + data.message);
      finishReply("");
      break;
    case "unloaded":
      state.loadedId = null; setStatus(); updateComposer();
      break;
  }
};
worker.onerror = (e) => toast("Worker error: " + (e.message || "unknown"));

/* ---------- model loading ---------- */
function loadModel(m) {
  if (state.loading || state.generating) return;
  state.loading = true;
  state.pending = m;
  state.loadedId = null;
  $("#loadbar").hidden = false;
  $("#loadProgress").hidden = false;
  $("#loadProgress").value = 0;
  $("#loadError").hidden = true;
  $("#loadLabel").textContent = "Starting…";
  $("#loadPct").textContent = "";
  if ($("#settings").open) $("#settings").close();
  setStatus(); updateComposer();
  worker.postMessage({ type: "load", model: { id: m.id, dtype: m.dtype } });
}

async function renderModels() {
  const list = $("#modelList");
  const rows = [];
  for (const m of allModels()) {
    const info = await cachedInfo(m.id);
    const loaded = state.loadedId === m.id;
    const status = loaded ? "Loaded" : info.cached ? `On device${info.bytes ? " · " + fmtBytes(info.bytes) : ""}` : "Not downloaded";
    const actions = el("div", { class: "actions" });
    if (!loaded) {
      actions.append(el("button", {
        type: "button", class: "primary small", disabled: state.loading,
        textContent: info.cached ? "Load" : "Download",
        onclick: () => loadModel(m),
      }));
    }
    if (info.cached) {
      actions.append(el("button", {
        type: "button", class: "ghost danger small", textContent: "Delete",
        onclick: async () => {
          if (!confirm(`Delete ${m.name} from this device?`)) return;
          if (loaded) worker.postMessage({ type: "unload" });
          await deleteCached(m.id);
          toast(`${m.name} deleted`);
          renderModels(); renderStorage();
        },
      }));
    }
    rows.push(el("li", { class: "model" },
      el("div", { class: "info" },
        el("strong", {}, m.name),
        el("span", { class: "muted" }, `${m.size} download · ${m.ram} RAM`),
        m.note ? el("span", { class: "muted" }, m.note) : "",
        el("span", { class: loaded ? "tag on" : "tag" }, status)),
      actions));
  }
  list.replaceChildren(...rows);
}

async function renderStorage() {
  try {
    const { usage, quota } = await navigator.storage.estimate();
    $("#storage").textContent = `Using ${fmtBytes(usage)} of about ${fmtBytes(quota)} available. Chats and models never leave this device.`;
  } catch {
    $("#storage").textContent = "Chats and models never leave this device.";
  }
}

/* ---------- settings dialog ---------- */
function openSettings() {
  $("#system").value = state.settings.system;
  $("#temp").value = state.settings.temperature;
  $("#tempOut").textContent = state.settings.temperature;
  $("#maxTokens").value = state.settings.maxTokens;
  $("#maxOut").textContent = state.settings.maxTokens;
  renderModels(); renderStorage();
  $("#settings").showModal();
}
function saveSettings() {
  state.settings.system = $("#system").value.trim() || "You are a helpful assistant.";
  state.settings.temperature = Number($("#temp").value);
  state.settings.maxTokens = Number($("#maxTokens").value);
  $("#tempOut").textContent = state.settings.temperature;
  $("#maxOut").textContent = state.settings.maxTokens;
  store.set("settings", state.settings);
}
$("#openSettings").onclick = openSettings;
$("#emptyCta").onclick = openSettings;
$("#closeSettings").onclick = () => $("#settings").close();
["system", "temp", "maxTokens"].forEach((id) => $("#" + id).addEventListener("input", saveSettings));
$("#addCustom").onclick = () => {
  const id = $("#customId").value.trim();
  if (!/^[\w.-]+\/[\w.-]+$/.test(id)) return toast("Use the form owner/model-name");
  if (allModels().some((m) => m.id === id)) return toast("Already in the list");
  state.customModels.push({ id, name: id.split("/")[1], note: "Custom model", size: "unknown", ram: "unknown", dtype: { webgpu: "q4f16", wasm: "q4" } });
  store.set("customModels", state.customModels);
  $("#customId").value = "";
  renderModels();
};
$("#clearChat").onclick = () => {
  if (!confirm("Clear all chat history?")) return;
  state.history = []; store.set("history", []);
  $("#messages").replaceChildren();
  $("#settings").close();
};

/* ---------- composer ---------- */
function autosize() {
  const t = $("#input");
  t.style.height = "auto";
  t.style.height = Math.min(t.scrollHeight, 140) + "px";
}
$("#input").addEventListener("input", autosize);
$("#input").addEventListener("keydown", (e) => {
  if (e.key === "Enter" && !e.shiftKey && matchMedia("(pointer: fine)").matches) { e.preventDefault(); send(); }
});
$("#sendBtn").onclick = send;

/* ---------- boot ---------- */
for (const m of state.history) addMsg(m.role, m.content);
setStatus(); updateComposer();

if (!("gpu" in navigator)) toast("WebGPU not available here. Using slower CPU mode.");

// Auto-load last model if it is already on the device (works offline).
(async () => {
  const m = allModels().find((x) => x.id === state.lastModelId);
  if (m && (await cachedInfo(m.id)).cached) loadModel(m);
})();

if ("serviceWorker" in navigator && import.meta.env.PROD) {
  window.addEventListener("load", () => navigator.serviceWorker.register("./sw.js").catch(() => {}));
}
