// All inference runs here so the UI thread stays smooth.
import { pipeline, TextStreamer, InterruptableStoppingCriteria, env } from "@huggingface/transformers";

env.allowLocalModels = false;
env.useBrowserCache = true; // model files persist in Cache API -> works offline after first download

const post = (type, data = {}) => self.postMessage({ type, ...data });
const stopper = new InterruptableStoppingCriteria();
let generator = null;

async function pickDevice() {
  try {
    if (self.navigator && navigator.gpu) {
      const adapter = await navigator.gpu.requestAdapter();
      if (adapter) return "webgpu";
    }
  } catch (_) {}
  return "wasm";
}

function makeProgress() {
  const files = new Map();
  let last = 0;
  return (p) => {
    if (p.status === "progress" && p.total) {
      files.set(p.file, { loaded: p.loaded, total: p.total });
    } else if (p.status === "done" && files.has(p.file)) {
      const f = files.get(p.file);
      f.loaded = f.total;
    } else if (p.status !== "progress") {
      return;
    }
    const now = performance.now();
    if (p.status === "progress" && now - last < 80) return; // throttle
    last = now;
    let loaded = 0, total = 0;
    for (const f of files.values()) { loaded += f.loaded; total += f.total; }
    post("progress", { file: p.file, loaded, total });
  };
}

async function load({ id, dtype }) {
  if (generator) { try { await generator.dispose(); } catch (_) {} generator = null; }
  const preferred = await pickDevice();
  const order = preferred === "webgpu" ? ["webgpu", "wasm"] : ["wasm"];
  let lastErr;
  for (const device of order) {
    try {
      post("device", { device });
      generator = await pipeline("text-generation", id, {
        device,
        dtype: dtype[device],
        progress_callback: makeProgress(),
      });
      // Warm-up: compiles GPU shaders so the first real reply is not slow.
      await generator([{ role: "user", content: "hi" }], { max_new_tokens: 1 });
      post("ready", { device });
      return;
    } catch (err) {
      lastErr = err;
      generator = null;
    }
  }
  post("load-error", { message: String((lastErr && lastErr.message) || lastErr) });
}

async function generate({ messages, params }) {
  if (!generator) { post("gen-error", { message: "No model loaded." }); return; }
  stopper.reset();
  let tokens = 0;
  let t0 = 0;
  const streamer = new TextStreamer(generator.tokenizer, {
    skip_prompt: true,
    skip_special_tokens: true,
    callback_function: (text) => post("token", { text }),
    token_callback_function: () => {
      if (!tokens++) t0 = performance.now();
    },
  });
  try {
    await generator(messages, {
      max_new_tokens: params.maxTokens,
      do_sample: params.temperature > 0,
      temperature: params.temperature || undefined,
      top_p: 0.95,
      repetition_penalty: 1.1,
      streamer,
      stopping_criteria: stopper,
    });
    const secs = (performance.now() - t0) / 1000;
    post("done", { tps: tokens > 1 && secs > 0 ? (tokens - 1) / secs : 0 });
  } catch (err) {
    post("gen-error", { message: String((err && err.message) || err) });
  }
}

self.onmessage = async ({ data }) => {
  switch (data.type) {
    case "load": return load(data.model);
    case "generate": return generate(data);
    case "stop": return stopper.interrupt();
    case "unload":
      if (generator) { try { await generator.dispose(); } catch (_) {} generator = null; }
      return post("unloaded");
  }
};
