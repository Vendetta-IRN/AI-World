// Sizes / RAM are rough estimates. Real size appears after download.
// dtype is per device: WebGPU likes q4f16, WASM (CPU) needs q4.
export const MODELS = [
  {
    id: "onnx-community/Qwen2.5-0.5B-Instruct",
    name: "Qwen 2.5 0.5B",
    note: "Best default. Fast on most phones.",
    size: "~0.5–0.8 GB", ram: "~1 GB",
    dtype: { webgpu: "q4f16", wasm: "q4" },
  },
  {
    id: "onnx-community/SmolLM2-360M-Instruct",
    name: "SmolLM2 360M",
    note: "Smallest and quickest. Simple answers only.",
    size: "~0.25–0.4 GB", ram: "~0.8 GB",
    dtype: { webgpu: "q4f16", wasm: "q4" },
  },
  {
    id: "onnx-community/LFM2-350M-ONNX",
    name: "Liquid LFM2 350M",
    note: "Small LFM model. Needs a recent Transformers.js.",
    size: "~0.25–0.4 GB", ram: "~0.8 GB",
    dtype: { webgpu: "q4f16", wasm: "q4" },
  },
  {
    id: "onnx-community/gemma-3-1b-it-ONNX",
    name: "Gemma 3 1B",
    note: "Better answers. Needs a newer phone.",
    size: "~0.8–1.1 GB", ram: "~2 GB",
    dtype: { webgpu: "q4f16", wasm: "q4" },
  },
  {
    id: "onnx-community/Qwen2.5-1.5B-Instruct",
    name: "Qwen 2.5 1.5B",
    note: "Strongest here. Flagship phones only.",
    size: "~1.0–1.6 GB", ram: "~2.5 GB",
    dtype: { webgpu: "q4f16", wasm: "q4" },
  },
];

const CACHE = "transformers-cache"; // Transformers.js browser cache name

export function fmtBytes(n) {
  if (!n) return "0 MB";
  const mb = n / 1048576;
  return mb >= 1024 ? (mb / 1024).toFixed(2) + " GB" : Math.round(mb) + " MB";
}

/** Is this model fully stored on the device? Sum sizes from content-length headers. */
export async function cachedInfo(modelId) {
  try {
    const cache = await caches.open(CACHE);
    const keys = await cache.keys();
    let hits = 0, bytes = 0;
    for (const req of keys) {
      if (!req.url.includes(`/${modelId}/`)) continue;
      hits++;
      const res = await cache.match(req);
      bytes += Number(res?.headers.get("content-length")) || 0;
    }
    return { cached: hits > 0, bytes };
  } catch {
    return { cached: false, bytes: 0 };
  }
}

export async function deleteCached(modelId) {
  const cache = await caches.open(CACHE);
  const keys = await cache.keys();
  await Promise.all(keys.filter((r) => r.url.includes(`/${modelId}/`)).map((r) => cache.delete(r)));
}
