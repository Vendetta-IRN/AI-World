import { defineConfig } from "vite";

export default defineConfig({
  base: "./", // relative paths: works on GitHub Pages sub-paths, Vercel, anywhere
  build: { target: "esnext" },
  worker: { format: "es" },
  optimizeDeps: { exclude: ["@huggingface/transformers"] },
});
