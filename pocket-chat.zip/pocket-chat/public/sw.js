/* Service worker: caches the app shell + ONNX runtime files so the app opens offline.
   Model weights are NOT handled here: Transformers.js stores them in the Cache API
   ("transformers-cache") by itself. Bump VERSION on every deploy. */
const VERSION = "v1";
const SHELL = `pocketchat-shell-${VERSION}`;
const RUNTIME = `pocketchat-runtime-${VERSION}`;
const PRECACHE = ["./", "./index.html", "./manifest.webmanifest", "./icon.svg", "./icon-192.png", "./icon-512.png"];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(SHELL).then((c) => c.addAll(PRECACHE)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys()
      .then((keys) => Promise.all(
        keys.filter((k) => k.startsWith("pocketchat-") && !k.endsWith(VERSION)).map((k) => caches.delete(k))
      ))
      .then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  const sameOrigin = url.origin === self.location.origin;
  const ortRuntime = url.hostname === "cdn.jsdelivr.net"; // onnxruntime-web .wasm/.mjs
  if (!sameOrigin && !ortRuntime) return; // hf.co model files: leave to Transformers.js

  if (req.mode === "navigate") {
    e.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(SHELL).then((c) => c.put("./index.html", copy));
          return res;
        })
        .catch(() => caches.match("./index.html"))
    );
    return;
  }

  e.respondWith(
    caches.match(req).then((hit) =>
      hit ||
      fetch(req).then((res) => {
        if (res.status === 200) {
          const copy = res.clone();
          caches.open(RUNTIME).then((c) => c.put(req, copy));
        }
        return res;
      })
    )
  );
});
