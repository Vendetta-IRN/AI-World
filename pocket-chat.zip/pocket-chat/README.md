# Pocket Chat — offline AI chat PWA

Runs a small open-source LLM fully in the browser. No server, no API keys, no data leaves the device.

- Engine: Transformers.js (ONNX Runtime Web). WebGPU if available, WASM (CPU) fallback.
- Inference in a Web Worker (`src/worker.js`), UI thread stays smooth.
- Models download from Hugging Face once, stored in the browser Cache API, then work offline.
- Service worker (`public/sw.js`) caches app shell + ONNX runtime files.

## Run

```bash
npm install
npm run dev        # http://localhost:5173
```

WebGPU and service workers need a secure context: `localhost` or HTTPS.
Opening `http://<lan-ip>:5173` on a phone is NOT secure, so GPU and install will not work.
Test on phone by deploying (below), or Chrome remote debugging with port forwarding to localhost.

## Build and deploy (static)

```bash
npm run build      # output in dist/
```

- GitHub Pages: push to `main`, enable Pages -> Source: GitHub Actions (workflow included).
- Vercel / Netlify: framework Vite, build `npm run build`, output `dist`.

Bump `VERSION` in `public/sw.js` on every deploy so phones fetch the new shell.

## Use on phone

1. Open the HTTPS URL in Chrome (Android). First visit must be online.
2. Models -> pick one -> Download. Wait for 100% and "ready".
3. Menu -> Install app / Add to Home screen.
4. Turn on airplane mode. App and model still work.

## Where things are

| Need | File |
|---|---|
| Add / change models | `src/models.js` |
| Engine init, device pick, WASM fallback, streaming, stop | `src/worker.js` |
| UI, download progress, delete model | `src/main.js` |
| Offline shell | `public/sw.js` |

Custom model: Models -> "Add a model from Hugging Face" -> `owner/name`
(must be a Transformers.js ONNX text-generation repo, ideally with `q4f16` and `q4` files).

## Limits (honest)

- WASM CPU mode is slow (about 1-5 tokens/s on phones). WebGPU is much faster.
- Multi-thread WASM needs COOP/COEP headers; GitHub Pages cannot set them, so CPU mode is single-thread there.
- Model sizes and RAM in the list are estimates. Models above ~1 GB may crash on low-RAM phones.
- Only the last 12 messages are sent to the model (small context window).
- WebLLM (MLC) was not used: it has no WASM CPU fallback, WebGPU only.
